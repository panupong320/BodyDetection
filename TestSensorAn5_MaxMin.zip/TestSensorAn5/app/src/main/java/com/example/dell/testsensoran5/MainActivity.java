package com.example.dell.testsensoran5;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.MenuItem;
import android.content.Context;

import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.DriverPropertyInfo;

public class MainActivity extends AppCompatActivity {

    private TextView xAText_max, yAText_max, zAText_max, xAText_min, yAText_min, zAText_min, xGText_max, yGText_max, zGText_max, xGText_min, yGText_min, zGText_min;
    private Sensor gyroSensor, acceleroSensor;
    private SensorManager SM;



    public SensorEventListener acceleroListen = new SensorEventListener() {
        float xA_max = -20;
        float yA_max = -20;
        float zA_max = -20;
        float xA_min = 20;
        float yA_min = 20;
        float zA_min = 20;

        @Override
        public void onSensorChanged(SensorEvent sensorEvent) {
            float xA = sensorEvent.values[0];
            float yA = sensorEvent.values[1];
            float zA = sensorEvent.values[2];

            // maximum value
            if(xA > xA_max) {
                xA_max = xA;
            }
            if(yA > yA_max) {
                yA_max = yA;
            }
            if(zA > zA_max) {
                zA_max = zA;
            }

            // minimum value
            if(xA < xA_min) {
                xA_min = xA;
            }
            if(yA < yA_min) {
                yA_min = yA;
            }
            if(zA < zA_min) {
                zA_min = zA;
            }

            xAText_max.setText("X: " + xA_max + " m/s2");
            yAText_max.setText("Y: " + yA_max + " m/s2");
            zAText_max.setText("Z: " + zA_max + " m/s2");

            xAText_min.setText("X: " + xA_min + " m/s2");
            yAText_min.setText("Y: " + yA_min + " m/s2");
            zAText_min.setText("Z: " + zA_min + " m/s2");
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {
            //Not it use
        }
    };

    public SensorEventListener gyroListen = new SensorEventListener() {
        float xG_max = -20;
        float yG_max = -20;
        float zG_max = -20;
        float xG_min = 20;
        float yG_min = 20;
        float zG_min = 20;

        @Override
        public void onSensorChanged(SensorEvent sensorEvent) {
            float xG = sensorEvent.values[0];
            float yG = sensorEvent.values[1];
            float zG = sensorEvent.values[2];

            // maximum value
            if(xG > xG_max) {
                xG_max = xG;
            }
            if(yG > yG_max) {
                yG_max = yG;
            }
            if(zG > zG_max) {
                zG_max = zG;
            }

            // minimum value
            if(xG < xG_min) {
                xG_min = xG;
            }
            if(yG < yG_min) {
                yG_min = yG;
            }
            if(zG < zG_min) {
                zG_min = zG;
            }

            xGText_max.setText("X: " + xG_max + " rad/s");
            yGText_max.setText("X: " + yG_max + " rad/s");
            zGText_max.setText("X: " + zG_max + " rad/s");

            xGText_min.setText("X: " + xG_min + " rad/s");
            yGText_min.setText("X: " + yG_min + " rad/s");
            zGText_min.setText("X: " + zG_min + " rad/s");
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {
            //Not it use
        }
    };

    /*@Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        xGText.setText("X: " + sensorEvent.values[0]);
        yGText.setText("Y: " + sensorEvent.values[1]);
        zGText.setText("Z: " + sensorEvent.values[2]);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {
        //Not it use
    }*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Create our Sensor Manager
        SM = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        // Accelerometer Sensor
        acceleroSensor = SM.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        gyroSensor = SM.getDefaultSensor(Sensor.TYPE_GYROSCOPE);

        // Register sensor Listener
        SM.registerListener(acceleroListen, acceleroSensor, SensorManager.SENSOR_DELAY_NORMAL);
        SM.registerListener(gyroListen, gyroSensor, SensorManager.SENSOR_DELAY_NORMAL);

        // Assign TextView
        xAText_max = (TextView)findViewById(R.id.xAText_max);
        yAText_max = (TextView)findViewById(R.id.yAText_max);
        zAText_max = (TextView)findViewById(R.id.zAText_max);

        xAText_min = (TextView)findViewById(R.id.xAText_min);
        yAText_min = (TextView)findViewById(R.id.yAText_min);
        zAText_min = (TextView)findViewById(R.id.zAText_min);

        xGText_max = (TextView)findViewById(R.id.xGText_max);
        yGText_max = (TextView)findViewById(R.id.yGText_max);
        zGText_max = (TextView)findViewById(R.id.zGText_max);

        xGText_min = (TextView)findViewById(R.id.xGText_min);
        yGText_min = (TextView)findViewById(R.id.yGText_min);
        zGText_min = (TextView)findViewById(R.id.zGText_min);

    }
}
